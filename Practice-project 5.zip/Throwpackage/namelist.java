package Throwpackage;

public class namelist {
	public String[] a = {"harshaa","vardhan", "sriram"};
}
