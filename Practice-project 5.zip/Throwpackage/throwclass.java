package Throwpackage;
class a{
	int a =1, b=0;
	public void result() {
		if(b==0) {
			throw new ArithmeticException("B value is zero");
		}else {
			System.out.println("result "+a/b);
		}
	}
}
public class throwclass {
	
	public static void main(String arg[]) {
		a n= new a();
		 try {
			 n.result();
		 }catch(ArithmeticException e) {
			 System.out.println(e.getMessage());
		 }
	}
}
