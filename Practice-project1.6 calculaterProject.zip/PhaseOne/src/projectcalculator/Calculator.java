
//As a developer, write a Java code to create a calculator to perform the four basic
//arithmetic operations (addition, subtraction, multiplication, and division)


package projectcalculator;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator {
	
	public int main() {
		
		
		System.out.println("press 1 for Addition");
		System.out.println("press 2 for substraction");
		System.out.println("press 3 for multiplication");
		System.out.println("press 4 for division");
		
		Scanner input  = new Scanner(System.in);
		int option=0;
		
		System.out.println("Enter The Option");
		try {
			option =input.nextInt();
		}catch(InputMismatchException e) {
			System.err.println("Enter the currect input");return 0;
		}
		
		int a=0,b=0;
		
		System.out.println("Enter A value");
		try {
			a=input.nextInt();
			
		}catch(InputMismatchException e) {
			System.out.println("Enter the currect value");return 0;
			
		}
		
		
		System.out.println("Enter B value");
		try {
			b=input.nextInt();
			
		}catch(InputMismatchException e) {
			System.out.println("Enter the currect value");return 0;
			
		}
		
		
		
		switch (option){
			case 1:
				return a+b;
				
			case 2:
				return a-b;
			case 3:
				return a*b;
			case 4:
				if(b==0) {
					throw new ArithmeticException("Can't do process ");
				}
				return a/b;
			default:
				System.out.println("Enter the currect option");
				
		}
		return 0;
		
	}
	public static void main(String args[]) {
	
		Calculator v =new Calculator();
		System.out.println("Answer:-- "+v.main());
	}
}
