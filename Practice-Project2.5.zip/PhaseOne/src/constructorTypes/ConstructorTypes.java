//2.2.1  Writing a program in Java to verify the implementations of constructor types




package constructorTypes;

public class ConstructorTypes {
	
	
	//There Are two types of constructor 
	//1. without parameterized constructor
	//2. parameterized constructor
	
	
	//1
	public ConstructorTypes(int a, int b) {
		System.out.printf("From parameter constructer a value %s and value %s", a,b);
		
	}
	//2
	public ConstructorTypes() {
		System.out.println("No parameters and no values ");
	}

	public static void main(String[] args) {
		
		
//		2.2.2 Executing the program and verifying constructors

		ConstructorTypes b = new ConstructorTypes();
		ConstructorTypes b1 = new ConstructorTypes(2,3);


	}

}
