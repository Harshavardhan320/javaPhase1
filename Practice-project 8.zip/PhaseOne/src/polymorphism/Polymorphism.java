package polymorphism;
class Overloading{
	
	public int solution(int a, int b) {
		
		return a-b;
	}
	public int solution(int a, int b, int c) {
		
		return a-b-c;
	}
}
class OverriddingA {
	
	public int addition(int a,int b) {
		
		return a+b;
	}
}
class OverriddingB extends OverriddingA{
	
	public int addition(int a, int b, int c) {
		
		return a+b+c;
	}
}
public class Polymorphism {
	
	public static void main(String args[]) {
		
		
		System.out.println("Overloading");
		
		Overloading j = new Overloading();
		System.out.println(j.solution(1, 2));
		System.out.println(j.solution(1, 2, 4));
		
		
		
		System.out.println("\nOverridding");
		
		OverriddingB b = new OverriddingB();
		System.out.println(b.addition(2, 3));
		System.out.println(b.addition(2, 3, 4));
		

	}
}






