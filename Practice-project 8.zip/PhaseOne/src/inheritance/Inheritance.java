package inheritance;
class motor{
	public int gare;
	public int speed =0;
	public motor(int gare) {
		this.gare =gare;
		if(gare >=1 )
			speed =10;
	}
	public int speed() {
		
		return gare*speed;
	}
}
class motorcycle extends motor{
	public String name;
	public motorcycle(String name, int gare) {
		super(gare);
		this.name =name;
	}
	public int motorcyclespeed() {
		return speed();
	}
}
public class Inheritance {
	
	public static void main(String args[]) {
		
		System.out.println("gare 1 speed "+ new motorcycle("contander", 1).motorcyclespeed());
		System.out.println("gare 3 speed "+ new motorcycle("contander", 2).motorcyclespeed());
		System.out.println("gare 3 speed "+ new motorcycle("contander", 3).motorcyclespeed());
		System.out.println("gare 4 speed "+ new motorcycle("contander", 4).motorcyclespeed());
		System.out.println("gare 2 speed "+ new motorcycle("contander", 1).motorcyclespeed());
		System.out.println("gare 1 speed "+ new motorcycle("contander", 0).motorcyclespeed());
	}

}
