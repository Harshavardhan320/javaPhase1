package ThreadCreate;

public class ThreadTwo implements Runnable{

	int count =0;
	@Override
	public void run() {
		for(int i=0; i<=10; i++) {
			count +=i;
			System.out.println(count);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("error");
			}
		}
		System.out.println("Thread Ended Final count "+count);
		
	}

	public static void main(String args[]) {
		ThreadTwo h = new ThreadTwo();
		
		h.run();
	}
}
