package ThreadCreate;

public class NumberCount extends Thread {
	
	@Override
	public void run() {
		for(int i=0; i<=10; i++) {
			System.out.println("Number Count "+i);
		}
		System.out.println("Thread Ended");
	}
	public static void main(String args[]) {
		NumberCount n = new NumberCount();
		n.start();
	}
}
