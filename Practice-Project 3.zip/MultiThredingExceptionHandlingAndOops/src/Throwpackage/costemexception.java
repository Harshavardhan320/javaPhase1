package Throwpackage;
class namenotfound extends Exception{
		

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public namenotfound(String s) {
		super(s);
	}
}
public class costemexception {
	public static void main(String args[]) {
		try {
			searchname("harshaa");
		}catch(namenotfound e) {
			System.out.println(e.getMessage());
		}finally {
			System.out.println("Finnally block all ways execute in any case of failer");
		}
	}
	public static void searchname(String name) throws namenotfound{
		namelist a = new namelist();
		int count=0;
		for(int i=0; i<a.a.length; i++) {
			if(a.a[i].equals(name)) {
				count++;
			}
		}
		if(count==0) {
			throw new namenotfound("Name Not founded");
		}else {
			System.out.println("Name Matched "+name);
		}
	}
}
