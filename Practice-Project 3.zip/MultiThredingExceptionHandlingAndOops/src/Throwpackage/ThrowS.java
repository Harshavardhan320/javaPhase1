package Throwpackage;
class throws1{
	public void addition() throws ArithmeticException{
		int a=0, b=9, c=8;
		System.out.println(b/c);
		System.out.println(c/a);
	}
}
public class ThrowS {
	public static void main(String args[]) {
		throws1 n = new throws1();
		try {
			n.addition();
		}catch(ArithmeticException e) {
			System.err.println(e.getMessage());
		}
	}
}
