package threadsleepwait;

public class Sleepwait {

	static int count =0;
	public static void main(String[] args) {
		
		Thread thread1 = new Thread(new Runnable(){
			@Override
			public void run() {
				for(int i=0; i<= 10; i++) {
					count +=i;
					try {
						Thread.sleep(100);
					}catch(InterruptedException e) {
						System.out.println("error");
					}
					System.out.print(i+" +");
					
				}
			}
		});
		thread1.start();
		synchronized (thread1) {
			try {
				thread1.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("final count of i is "+count);

	}

}
