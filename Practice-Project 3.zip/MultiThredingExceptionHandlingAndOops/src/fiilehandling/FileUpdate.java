package fiilehandling;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;

public class FileUpdate {
    public static void main(String args[]) {
        String pathString = "D:\\Eclips java programs\\PhaseOneProject\\src\\fiilehandling\\newfilr.txt";
        Path filePath = Paths.get(pathString);

        try {
            
            List<String> lines = Files.readAllLines(filePath);

            
            lines.add("This line is added for update.");

            
            Files.write(filePath, lines);

            System.out.println("File updated successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

