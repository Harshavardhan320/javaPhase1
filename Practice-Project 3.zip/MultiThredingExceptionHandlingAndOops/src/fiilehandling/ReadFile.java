package fiilehandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class ReadFile {
	public static void main(String args[]) {
		String path = "D:\\Eclips java programs\\PhaseOneProject\\src\\fiilehandling\\newfilr.txt";
		Path a = Path.of(path);
		List<String> lines =null;
		try {
			lines = Files.readAllLines(a);
		} catch (IOException e) {
			System.out.println("Error");
		}
		
		for(String l: lines) {
			System.out.println(l);
		}
	}
}
