//Writing a program in Java to create a file

package fiilehandling;

import java.io.FileWriter;
import java.io.IOException;

public class FileCreation {
	public static void main(String args[]) {
		String path = "D:\\Eclips java programs\\PhaseOneProject\\src\\fiilehandling\\newfilr.txt";
		
		
		FileWriter fw =null;
		try {
			fw = new FileWriter(path);
			fw.write("iam harsha\n");
			fw.write("iam writing some thing");
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fw.close();
			} catch (IOException e) {
				System.out.println("Error");
			}
		}
		
	}
}
