package fiilehandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Deletefile {

	public static void main(String[] args) {
		String path = "D:\\Eclips java programs\\PhaseOneProject\\src\\fiilehandling\\newfilr.txt";
		 
        try {
			Files.deleteIfExists(Paths.get(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
