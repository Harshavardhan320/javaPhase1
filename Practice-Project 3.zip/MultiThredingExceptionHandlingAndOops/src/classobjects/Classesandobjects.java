package classobjects;
class SelfDetails{
	public String name;
	public int age;
	public long number;
	
	public SelfDetails(String name, int age, long number) {
		
		this.name = name;
		this.age = age;
		this.number = number;
	}
	
	public void appraved(String name) {
		if(this.age >= 18 && this.age <= 30)
			System.out.println("You In Grp "+name);
		else
			System.out.println("Not in grp "+name);
	}
	
	
}
public class Classesandobjects {
	public static void main(String ages[]) {
		SelfDetails h3 = new SelfDetails("harsha", 12, 8074813842L);
		SelfDetails h2 = new SelfDetails("sindhu", 39, 8074813841L);
		SelfDetails h1 = new SelfDetails("vani", 18, 8074813840L);
		
		System.out.printf("Applied Names %s , %s, %s \n", h1.name, h2.name, h3.name);
		
		h1.appraved(h1.name);
		h2.appraved(h2.name);
		h3.appraved(h3.name);
	}
	
	
	
}
