package classobjects;
class encapsulation{
	private String name;
	private int age;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
}
public class main {
	public static void main(String args[]){
		encapsulation u = new encapsulation();
		u.setAge(34);
		u.setName("harsha");
		
		System.out.printf("Name %s and age %s", u.getName(), u.getAge());
		
	}
}
