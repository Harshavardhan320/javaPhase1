package classobjects;
abstract class amazon {
	public String name;
	public String password;
	public abstract void login(String name, String password);
	public void register(String name , String password ) {
		if(name !="" && password !="") {
			this.name =name;
			this.password =password;
			System.out.println("You are register with "+name);
		}else {
			System.out.println("Fails");
		}
	}
}
public class Abstraction extends amazon{

	@Override
	public void login(String name, String password) {
		if(this.name==name && this.password==password) {
			System.out.println("Login into amazon account");
		}else {
			System.out.println("login fails in valid login id password");
		}
		
	}
	public static void main(String age[]) {
		Abstraction b =new Abstraction();
		b.register("harsha", "vardhan");
		b.login("harsha", "vardhan");
		
		
		System.out.println("\nSecound login");
		Abstraction b1 =new Abstraction();
		b1.register("harsh1a", "");
		b1.login("harsha", "vardhan");

	}

}
