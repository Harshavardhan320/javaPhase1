package practiceproject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileHandlingProject {
	public static void main(String args[]) {
		String path = "D:\\Eclips java programs\\PhaseOneProject\\src\\practiceproject\\file.txt";
		
		
		StringBuffer stringbuild = new StringBuffer();
		stringbuild.append("my mane \t");
		stringbuild.append("katukojwala \t");
		stringbuild.append("harsha \t");
		stringbuild.append("vardhan \t");
		
		
		//file creating
		filecreation(path);

		
		//writing the content
		filewriter(path, stringbuild);
		
		//reading a file
		readfile(path);
		stringbuild.append("sunny");

		
		//for updating the file
		appendToFile(path,stringbuild);
		
		
	}
	public static void filecreation(String path) {
		File f = null;
		try {
			f =new File(path);
			if(f.createNewFile()) {
				System.out.println("File created");
			}else {
				System.out.println("File not created");
			}
		}catch(IOException e) {
			System.out.println("Error");
		}
		
	}
	public static void filewriter(String path, StringBuffer Content) {
		FileWriter fw =null;
		try {
			fw = new FileWriter(path);
			fw.write(Content.toString());
			System.out.println("file created and added content");
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fw.close();
			} catch (IOException e) {
				System.out.println("Error");
			}
		}
	
	}
	public static void readfile(String path) {
		Path p = Path.of(path);
		List<String> line = null;
		try {
			line = Files.readAllLines(p);
		}catch(IOException  e) {
			System.out.println("Error");
		}
		for(String a: line) {
			System.out.println(a);
		}
	}
	
	public static void appendToFile(String path,  StringBuffer Content) {

		  Path filePath = Paths.get(path);
        try {
            
            List<String> lines = Files.readAllLines(filePath);

            
            lines.add(Content.toString());

            
            Files.write(filePath, lines);

            System.out.println("File updated successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
