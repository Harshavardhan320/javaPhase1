package tryCatchstatements;

public class Trycatchblock {
	public static void main(String args[]) {
		int a[] = new int[4];
		a[0] = 5;
		a[1] =10;
		a[3] =0;
		try {
			System.out.printf("Resut of %s %s %s\n",a[0],a[3], a[0]/a[3]);
		}catch(ArithmeticException e){
			System.out.println("InCurrect Problem Sloving");
		}
		
		try {
			a[4] =10;
		}catch(IndexOutOfBoundsException e) {
			System.out.println("Out of memory");
		}
		
	}
}
