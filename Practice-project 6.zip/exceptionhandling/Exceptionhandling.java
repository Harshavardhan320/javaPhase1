package exceptionhandling;
class PhoneNumberNotFoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PhoneNumberNotFoundException(String message) {
		super(message);
	}
}
class Phonenumberdatabase{
	Long[] number = {9989101627L,8074813841L,9550864175L,7569861812L};
}
public class Exceptionhandling {
	
	public static void phonenumber(long number) throws PhoneNumberNotFoundException{
		Phonenumberdatabase num = new Phonenumberdatabase();
		int count=0;
		for(int i=0; i<num.number.length; i++) {
			if(num.number[i].equals(number)) {
				count++;
			}
		}
		if(count==0) {
			throw new PhoneNumberNotFoundException("No number like "+number);
		}else {
			System.out.printf("Your %s Found\n",number);
		}
	}
	public static void main(String args[]) {
		
		try {
			phonenumber(8074813841L);
		}catch(PhoneNumberNotFoundException e) {
			
		}finally{
			System.out.println("Thank You And Good Bye");
		}
	}
}
