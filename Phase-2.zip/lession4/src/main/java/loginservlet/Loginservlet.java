package loginservlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Loginservlet
 */
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		PrintWriter out = response.getWriter();
		if(username == null || password == null || username.equals("") || password.equals("")){
			out.print("null data");			
		}else {
			request.getRequestDispatcher("Project.jsp").include(request, response);
			out.printf("<center><h5 style=color:green>You entered data is %s %s</h5></center>",username,password);
		}
	}

}
