package diamondproblem;
interface Cat{
	default void eat() {
		System.out.println("Cat Can Eat Fishes");
	}
}
interface Dog{
	default void eat() {
		System.out.println("Dog Can Eat Meet");
	}
}
public class Animal implements Cat,Dog{

	@Override
	public void eat() {
		Cat.super.eat();
		Dog.super.eat();
	}
	
	public static void main(String args[]) {
		Animal hungry = new Animal();
		hungry.eat();
	}
}
