//2.5.1 Writing a program in Java to verify the implementation of inner classes


package innerclass;

public class InnerClass {
	private int a =23;
	public static int ab = 33;
	
	
	public class subclass1{
		private int insideclass1 =99;
		public int sub() {
			System.out.printf("From a method First value %s secound value is %s \n",a,ab);
			return a+ab;
		}
	}
	
	static class subclass2{
		private int insideclass2 =88;
		public int sub() {
			
			System.out.println("In static all the variables are accessed in the static way ony");
			System.out.printf("From a method First value %s secound value is %s",insideclass2,ab);
			return insideclass2+ab;
		}
	}
	public static void main(String args[]) {
		
		//2.5.2 Executing the program and verifying working of inner classes
		
		//subclass1 object
		subclass1 a1 = new InnerClass().new subclass1();
		a1.sub();
		System.out.println("subclass value "+a1.insideclass1);
	;
		
		System.out.println();
		//static innerclass();
		
		
		subclass2 a2 =new InnerClass.subclass2();
		a2.sub();
		System.out.println();
		System.out.println(a2.insideclass2);

		
	}
}
