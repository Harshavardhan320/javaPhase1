//2.3.1 Writing a program in Java to verify implementations of collections
package collections;

import java.util.ArrayList;

class details{
	public String name;
	public int age;
	public details(String name, int age) {
		this.name =name;
		this.age =age;
	}
	
}

public class Collections {
	
	public static void main(String args[]) {
		
		//Executing the program and verifying it is working
		
		ArrayList<Integer> b = new ArrayList<>();
		
		for(int a =1; a<=5; a++) {
			b.add(a);
		}
		
		System.out.println("Printing the elements");
	
		for(int a =0; a< b.size(); a++) {
			System.out.print(b.get(a)+", ");
		}
		
		
		
		System.out.println();
		
		ArrayList<details> n = new ArrayList<details>();
		n.add(new details("harhsa", 23));
		n.add(new details("vikas", 22));
		n.add(new details("ruchitha", 22));
		n.add(new details("navya", 22));
		
		
		n.forEach(obj1 -> System.out.println(String.valueOf(obj1.name)));
		
		n.sort((obj2,obj3)->(obj2.name).compareTo(obj3.name));
		
		System.out.println();
		System.out.println("sorted list by names");
		System.out.println();
		n.forEach(obj1 -> System.out.println(String.valueOf(obj1.name)));

		
	}
	
}








