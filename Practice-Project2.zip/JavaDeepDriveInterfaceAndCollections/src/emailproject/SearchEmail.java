package emailproject;

import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchEmail {
	public boolean main() {
		
		//STORING DATABASE
		Set<String> Email = new HashSet<String>();
		Email.add("sunnyharsha320@gmail.com");
		Email.add("katukojwalaharshavardhan@gmail.com");
		Email.add("sunnyharsha32@gmail.com");
		Email.add("sindhu@gmail.com");
		Email.add("vankanna@gmail.com");
		Email.add("vani@gmail.com");
		
		System.out.println("Enter The Searching Email Id");
		Scanner input = new Scanner(System.in);
		
		//DOMIN NAME
		final String Domin1 = "@gmail.com";
		
		//USER INPUT
		String emailid =null;
		try {
			emailid =input.next();
		}catch(Exception e) {
			System.err.println("Error input");
		}
		
		if(!emailid.substring(emailid.length()-10).equals(Domin1)) {
			System.out.println("Incurrect Email Id ");
			return false;
		}else {
			if(Email.contains(emailid)) {
				System.out.println("Your  Email ID Listed ");
				return true;
			}else {
				System.out.println("Your Not Email ID Listed ");
				return false;
			}
		}
	}
	
	
	public static void main(String args[]) {
		SearchEmail d = new SearchEmail();
		
		d.main();
	}
}
