
//2.8.1	Writing a program in Java to verify implementations of regular expressions


package expressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {
	
	public static void main(String args[]) {
		//2.8.1	Writing a program in Java to verify implementations of regular expressions
		
		
		String pattern = "[a-z]";
		String pattern1 = "[0-9]";
		String string = "asdaskdnbwf24234";
		
		Pattern a = Pattern.compile(pattern);
		Matcher c = a.matcher(string);
		while (c.find())
	      	System.out.print( string.substring( c.start(), c.end())+" ");
		
		Pattern aa = Pattern.compile(pattern1);
		System.out.println("\n\n finding numbers");
		Matcher f = aa.matcher(string);
		while(f.find()) {
			System.out.print(string.substring(f.start(),f.end())+" ");
		}
	}
}

