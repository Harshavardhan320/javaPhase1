//2.6.1 Writing a program in Java to verify implementations of strings, StringBuffer, and StringBuilder


package Strings;

public class StringDemo {
	public static void main(String args[]) {
		//2.6.2 Executing the program and verifying working of strings
		
		System.out.println("String methodes");
		
		String n1 = new String("iamharsha");
		
		System.out.println("String length :"+n1.length());
		
		System.out.println("Substring method "+n1.substring(1)+"\n"+"Another Substring method "+n1.substring(1, 5));
		
		String n2 = new String("iamnotharsha");
		
		System.out.println("Comparing two strings "+ n1.equals(n2));
		
		System.out.println("Verify the string empty or not "+n2.isEmpty());
		
		System.out.println("Converting to all lowercase "+n2.toLowerCase());
		
		System.out.println("replace method "+n2.replace("h","n"));
		
		System.out.println();
		
		System.out.println("String buffer");
		
		StringBuffer s=new StringBuffer("sunnyharsha320");
		
		System.out.println("String :"+s);
		
		System.out.println("Combining the string "+s.append("@gmail.com"));
		
		System.out.println("Add in a character using index number "+s.insert(0, 'S'));
		
		System.out.println("Replacing the characters with index number "+s.replace(0, 4, "hars"));
		
		System.out.println("Deleting the characters using index number "+ s.delete(0, 4));
		
		System.out.println("\n");
		
		System.out.println("Creating StringBuilder");
		
		StringBuilder m1=new StringBuilder("iamhappy");
		
		System.out.println("Adding the packet "+m1.append("iam"));
		
		System.out.println("deleting elements "+m1.delete(1, 6));
		
		System.out.println("inserting the string "+m1.insert(0,"not"));
		
		System.out.println("reverse order "+m1.reverse());
		
		System.out.println("\n");
		System.out.println("converting to string to stringbuilder");
		
		String a4 = "the worls";
		StringBuilder  h1 = new StringBuilder(a4);
		
		System.out.println(" the converting word "+h1);

		
		

		
	}
}
