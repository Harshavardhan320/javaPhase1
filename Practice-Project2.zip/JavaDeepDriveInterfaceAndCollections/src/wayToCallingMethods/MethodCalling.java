// 2.1.1 Writing a program in Java to verify implementations of methods and ways of calling a method    




package wayToCallingMethods;

public class MethodCalling {
	public int add(int a, int b) {
		return a+b;
	}
	public int add(int a, int b, int c) {
		return a+b+c;
	}
	public String sayname(String name) {
		return name.concat(" Hello");
	}
	public static void main(String args[]) {
		
		
//		2.1.2 Executing the program and verifying working of methods 
		
		
		MethodCalling n  =new MethodCalling();
		System.out.println(n.add(2,4));
		System.out.println(n.add(2,3,4));
		System.out.println(n.sayname("harsha"));
		
	}

}
