

//Writing a program in Java to verify implementation of arrays

package arrays;
class persionaldetails{
	public String name;
	public int age;
	public int number;
	public persionaldetails(String name, int age, int number) {
		this.name =name;
		this.age =age;
		this.number =number;
	}
}
public class ArraysClass {
	public static void main(String args[]) {
		int a[] = {1,2,3,4,5,6,7,78};
		for(int ab =0; ab< a.length; ab++) {
			System.out.print(a[ab]+" ");
		}
		
		
		System.out.println("\n");
		System.out.println("Concrate class");
		
		persionaldetails b[] = new persionaldetails[2];
		
		b[0] = new persionaldetails("harsha",23, 807481);
		b[1] = new persionaldetails("sindhu",20, 707481);
		
		for(int m =0; m < b.length; m++) {
			System.out.println("Name "+b[m].name+" ");
		}
	}
}
