package Accessmodifiers.src.modifiers.folder1;

import Accessmodifiers.src.modifiers.Accessmodifiers;

public class class1 {


	public static void main(String[] args) {
		Accessmodifiers m = new Accessmodifiers();
		// we can only access only public values by creating the object
		
		System.out.println(m.a);
		
		// we can not access value of private protected and default values
		
		
//		System.out.println(m.b);
//		System.out.println(m.n);
//		System.out.println(m.t);

	}

}
