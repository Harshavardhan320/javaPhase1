package Accessmodifiers.src.modifiers;

public class Accessmodifiers {
	public int a =12;
	private int b =78;
	protected int n = 58;
	int t= 10;
	
	public int m1() {
		return 1;
	}
	public static void main(String args[]) {
		// we can access all value in the class
		Accessmodifiers m = new Accessmodifiers();
		System.out.println(m.a);
		System.out.println(m.b);
		System.out.println(m.n);
		System.out.println(m.t);
	}
}
