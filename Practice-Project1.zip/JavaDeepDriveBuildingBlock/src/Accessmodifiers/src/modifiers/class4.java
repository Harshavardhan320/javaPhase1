package Accessmodifiers.src.modifiers;

public class class4 extends Accessmodifiers{

	public static void main(String args[]) {
		//we can access only public, 
		class4 m = new class4();
		System.out.println(m.a);
		System.out.println(m.n);
		System.out.println(m.t);
		
		//by extending the class we can not access the private variables
		//System.out.println(m.b);

	}

}
