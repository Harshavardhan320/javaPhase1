package forthsmalestelement;

import java.util.Arrays;

public class ForthSmallNumber {
	public static void smallestnumber(int[] o) {
		for(int i=0; i<o.length; i++) {
			for(int j=i; j<o.length; j++) {
				if(o[i]>o[j]) {
					o[i] = o[i] ^ o[j];
			        o[j] = o[i] ^ o[j];
			        o[i] = o[i] ^ o[j];
				}
			}
		}
		if(o.length >=4) {
			System.out.println("Forth Smallest number is "+o[3]);
		}else {
			System.out.printf("%s smallest number is %s ",o.length , o.length-1);
		}
	}
	public static void main(String[] a) {
		int[] o = {23,2,1124,56,7,32,8,8};
		
		smallestnumber(o);
	}
}
