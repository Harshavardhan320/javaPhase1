package sumNNumbers;

import java.util.Scanner;

public class SumNNNumbers {
    public static void main(String[] args) {
    	int a[] = {1,2,3,4,5,6,7,8,9,12};
    	for(int i=0; i<a.length; i++) {
    		System.out.print(a[i]+" ");
    	}
    	System.out.println();
    	Scanner input = new Scanner(System.in);
    	System.out.println("Enter the Left Range value");
    	int L = input.nextInt();
    	System.out.println("Enter the Right Range value");
    	int R = input.nextInt();
    	int n = a.length;

        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range");
            input.close();
            return;
        }
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += a[i];
        }
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
        input.close();
    }
}

