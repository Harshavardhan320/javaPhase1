package boubleSort;

public class Boublesort {
	public static void main(String args[]) {
		int[] a = {1,2,22,321,443,33};
		sort(a);
	}
	public static void sort(int[] arr) {
		int arrlength = arr.length;
		for(int i =0; i<arrlength-1; i++) {
			for(int j=0; j<arrlength-i-1; j++) {
				if(arr[j]>arr[j+1]) {
					  int temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
				}
			}
		}
		printarray(arr);
	}
	public static void printarray(int[] arr) {
		for(int a: arr) {
			System.out.print(a+" ");
		}
	}
}
