package exponentialSearch;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExponentialSearch {
	public static void main(String[] args) {
		int nums[] = {91, 120, 130, 456, 564};
		Scanner input  = new Scanner(System.in);
		System.out.println("Enter searching Element");
        int element = 0;
        try {
			element = input.nextInt();
		}catch(InputMismatchException e) {
			System.err.println("Error Input");
		}
		
		
		// Find the index of searched item
       int index_result = exponentialSearch(nums, element);
       
       if(index_result >0) {
           System.out.println(element + " is found at index " + index_result);		

       }else {
           System.out.println(element + " not found");		

       }

       input.close();
		
	}

	private static int exponentialSearch(int[] arr, int i) {
		int start_num = 0;
		
		if(arr[start_num] == i)
			return start_num;
		start_num =1;
		while(start_num < arr.length && arr[start_num] <= i) {
			start_num*=2;
		}
		return Arrays.binarySearch(arr, start_num/2, Math.min(start_num, arr.length),i);
	}


}
