package linearSearch;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class LinearSearch {
	public static void main(String args[]) {
		int[] a = {3,1,22,34,56,8876,232,123,5,232};
		Scanner input  = new Scanner(System.in);
		System.out.println("Enter The searcing Element");
		int element = 0;
		
		try {
			element = input.nextInt();
		}catch(InputMismatchException e) {
			System.err.println("Error Input");
		}
		search(a, element);
		input.close();
	}

	private static void search(int[] a, int element) {
		int count =0;
		List<Integer> num = new ArrayList<>();
		for(int i=0; i<a.length; i++) {
			if(a[i] == element) {
				count++;
				num.add(i);
			}
		}
		if(count >=1) {
			System.out.printf("Element Found At %s\n",num+" Position");
		}else {
			System.out.println("Element Not Found");
		}
	}
}
