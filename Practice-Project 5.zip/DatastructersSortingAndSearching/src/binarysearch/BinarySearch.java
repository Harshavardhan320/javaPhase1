package binarysearch;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int[] a = {1,5,6,2,3,7,9,0};
		Scanner input  = new Scanner(System.in);
		System.out.println("Enter The searcing Element");
		int element = 0;
		
		try {
			element = input.nextInt();
		}catch(InputMismatchException e) {
			System.err.println("Error Input");
		}
		
		if(search(a, element) != -1) {
			System.out.println("element found ");
		}else {
			System.out.println("Element not found");
		}
		input.close();
		
	}
	public static int search(int[] arr, int element) {
		int arrlength = arr.length;
		for(int i =0; i<arrlength; i++) {
			for(int j=i; j<arrlength; j++) {
				if(arr[i]>arr[j]) {
					arr[i] = arr[i]^arr[j];
					arr[j] = arr[i]^arr[j];
					arr[i] = arr[i]^arr[j];
				}
			}
		}
		int start =0, end = arr.length;

		while(start <=end) {
			int mid = start +(end - start)/2;
			if(arr[mid] == element) {
				return arr[mid];
			}else if(arr[mid] < element) {
				start = mid+1;
			}else {
				end =mid-1;
			}
		}
		return -1;
	}
}
