package modifiers;

public class class3 {

	public static void main(String args[]) {
		Accessmodifiers m = new Accessmodifiers();
		
		//we can access only public/default unless we create object
		System.out.println(m.a);
		System.out.println(m.n);
		System.out.println(m.t);
		
		// we can can not access the private values in other class
//		System.out.println(m.b);
	}
}
