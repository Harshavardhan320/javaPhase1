// import { add } from './practice.js';

// document.write(add(1,3));