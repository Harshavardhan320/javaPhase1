interface school{
      schoolname:string;
      address: String;
      schoolId: number;
}
function hota(){
      
}