//2.4.1 Writing a program in Java to verify implementations of maps

package collections;

import java.util.HashMap;
import java.util.Map;

class selfdetails{
	public String name;
	public int age;
	public selfdetails(String name, int age) {
		this.name =name;
		this.age =age;
	}
	
}

public class Mapping {
	public static void main(String agrs[]) {
		
//		2.4.2 Executing the program and verifying it is working
		
		
		Map<String, Integer> details = new HashMap<>();
		
		details.put("harsha", 123456);
		details.put("harsha1", 1234567);
		details.put("harsha2", 12345678);
		details.put("harsha3", 123456789);
		
		for(String obj : details.keySet()) {
			System.out.println(obj +" : "+details.get(obj));
		}
		
		System.out.println();
		System.out.println("searching the values");
		System.out.println(details.containsKey("harsha"));
		
		//using rapper custum class
		
		HashMap<String, selfdetails> h = new HashMap<>();
		h.put("harsha", new selfdetails("harsha", 73) );
		h.put("ruchitha", new selfdetails("ruchitha", 43));
		h.put("navya", new selfdetails("navya", 53));
		h.put("vikas", new selfdetails("viks", 73));
		
		
		System.out.println();
		
		for(String onj : h.keySet()) {
			System.out.println("name "+onj+" age: "+h.get(onj).age);
		}
	}
}














